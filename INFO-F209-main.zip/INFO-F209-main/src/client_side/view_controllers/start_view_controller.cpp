
#include "start_view_controller.h"


StartViewController::StartViewController()
    : AbstractMenuViewController(std::make_shared<StartMenuView>()){}