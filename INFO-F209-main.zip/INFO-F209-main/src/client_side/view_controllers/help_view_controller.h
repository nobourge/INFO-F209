//
// Created by Anton Romanova on 23/02/2022.
//

#ifndef QUORIDOR_SRC_CLIENT_SIDE_VIEW_CONTROLLERS_HELP_VIEW_CONTROLLER_H_
#define QUORIDOR_SRC_CLIENT_SIDE_VIEW_CONTROLLERS_HELP_VIEW_CONTROLLER_H_

#include "abstract_authed_menu_view_controller.h"

class HelpViewController : public AbstractAuthedMenuViewController {
 public:
  HelpViewController();
};

#endif //QUORIDOR_SRC_CLIENT_SIDE_VIEW_CONTROLLERS_HELP_VIEW_CONTROLLER_H_
