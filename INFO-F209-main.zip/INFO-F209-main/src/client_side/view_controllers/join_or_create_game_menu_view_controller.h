//
// Created by Anton Romanova on 04/03/2022.
//

#ifndef QUORIDOR_SRC_CLIENT_SIDE_VIEW_CONTROLLERS_JOIN_OR_CREATE_GAME_MENU_VIEW_CONTROLLER_H_
#define QUORIDOR_SRC_CLIENT_SIDE_VIEW_CONTROLLERS_JOIN_OR_CREATE_GAME_MENU_VIEW_CONTROLLER_H_

#include "abstract_menu_view_controller.h"
class JoinOrCreateGameMenuViewController : public AbstractMenuViewController {
public:
  JoinOrCreateGameMenuViewController();
};

#endif // QUORIDOR_SRC_CLIENT_SIDE_VIEW_CONTROLLERS_JOIN_OR_CREATE_GAME_MENU_VIEW_CONTROLLER_H_
