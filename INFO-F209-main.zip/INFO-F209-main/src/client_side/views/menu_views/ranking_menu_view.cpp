#include "ranking_menu_view.h"


RankingMenuView::RankingMenuView() : AbstractMenuView(menu_name_) {}