#include "create_account_menu_view.h"
#include "../../view_controllers/home_menu_view_controller.h"


CreateAccountMenuView::CreateAccountMenuView() : AbstractMenuView(menu_name_) {}
