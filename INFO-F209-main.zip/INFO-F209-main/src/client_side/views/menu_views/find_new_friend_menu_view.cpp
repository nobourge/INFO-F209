//
// Created by Anton Romanova on 01/03/2022.
//

#include "find_new_friend_menu_view.h"

FindNewFriendMenuView::FindNewFriendMenuView()
    : AbstractMenuView(menu_name_) {}
