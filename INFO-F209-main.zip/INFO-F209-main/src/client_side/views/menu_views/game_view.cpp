//
// Created by guest on 01/03/2022.
//

#include "game_view.h"
GameView::GameView() : AbstractMenuView(menu_name_) {}


int GameView::GetVerticalGutterSize() const { return 0; }
