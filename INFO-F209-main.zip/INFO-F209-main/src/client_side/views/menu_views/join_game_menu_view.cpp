//
// Created by Anton Romanova on 04/03/2022.
//

#include "join_game_menu_view.h"

JoinGameMenuView::JoinGameMenuView() : AbstractMenuView(menu_name) {}
