//
// Created by Anton Romanova on 28/02/2022.
//

#include "friend_list_menu_view.h"
FriendListMenuView::FriendListMenuView() : AbstractMenuView(menu_name_) {
}
