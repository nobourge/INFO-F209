#include "chat_room_menu_view.h"



ChatRoomMenuView::ChatRoomMenuView() : AbstractMenuView(menu_name_) {}
